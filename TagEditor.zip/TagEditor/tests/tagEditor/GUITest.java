package tagEditor;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class GUITest{
	
	@Test
	public void TestTree (){
		
		Control myControler = new Control();
		assertNotNull(myControler);

	}
	
	
	

}
